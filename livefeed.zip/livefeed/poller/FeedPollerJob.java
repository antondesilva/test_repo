package com.livefeed.poller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.livefeed.feed.FeedCompletionStatus;
import com.livefeed.feed.FeedManager;
import com.livefeed.feed.FeedMonitorService;

@Component
public class FeedPollerJob {
	
	@Autowired
	FeedManager feedManager;
	
	@Autowired
	FeedMonitorService monitorService;
	
	@Scheduled(fixedRate=1000)
	public void feedPoller() 
	{
		if( feedManager.getFeedCompletionStatus() == FeedCompletionStatus.INCOMPLETE )
			monitorService.checkFeedStatus();
			
	}
}
