package com.livefeed.util;

import java.time.LocalDate;
import java.time.ZoneId;

public class TimeUtility {
	public static String currentDate()
	{
		return LocalDate.now( ZoneId.of( "America/Montreal" ) ).toString();
	}
}
