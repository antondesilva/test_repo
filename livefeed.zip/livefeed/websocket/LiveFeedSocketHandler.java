package com.livefeed.websocket;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

@Component
public class LiveFeedSocketHandler extends TextWebSocketHandler {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	SessionManager sessionManager;
	
	@Override
	public void handleTextMessage(WebSocketSession session, TextMessage message)
	{
		
	}
	
	@Override
	public void afterConnectionEstablished(WebSocketSession session)
	{
		System.out.println( session );
		sessionManager.addSession( session );
	}
	
	@Override
	public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception 
	{
		if( session == null ) 
			return;
		
		sessionManager.removeSession( session );
		if( status.getCode() == 1000 )
		{
			System.out.println(session + " terminated succesfully.");
		}
		else
		{
			System.out.println(session + " ended abnormally(status code: " + status.getCode() + ")" );
		}
	}
}
