package com.livefeed.websocket;

import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;

@Service
public class LiveFeedBroadcastService {
	
	@Autowired
	SessionManager sessionManager;
	
	public void broadcastFeedStatus(String message)
	{
		WebSocketMessage<String> socketMsg = new TextMessage( message );
		Set<WebSocketSession> sessions = sessionManager.getConnectedSessions();
		synchronized( sessions )
		{
			Iterator<WebSocketSession> itr = sessions.iterator();
			WebSocketSession session;
			while( itr.hasNext() )
			{
				try
				{
					session = itr.next();
					if( session.isOpen() )
						session.sendMessage( socketMsg );
				}
				catch(IOException ioe)
				{
					ioe.printStackTrace();
				}
			}
		}
	}
}
