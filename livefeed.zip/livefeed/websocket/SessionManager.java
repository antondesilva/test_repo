package com.livefeed.websocket;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketSession;

@Component
public class SessionManager {
	
	private Set<WebSocketSession> connectedSessions = Collections.synchronizedSet( 
			new HashSet<WebSocketSession>() );
	
	public SessionManager(){}
	
	public void addSession(WebSocketSession session)
	{
		this.connectedSessions.add( session );
	}
	
	public void removeSession(WebSocketSession session)
	{
		this.connectedSessions.remove( session );
	}

	public Set<WebSocketSession> getConnectedSessions() {
		return connectedSessions;
	}

	public void setConnectedSessions(Set<WebSocketSession> connectedSessions) {
		this.connectedSessions = connectedSessions;
	}
	
}
