package com.livefeed.feed;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.livefeed.websocket.LiveFeedBroadcastService;


@Service
public class FeedMonitorService {

	@Autowired
	FeedStatusDAOImpl feedStatusDao;
	@Autowired
	FeedManager feedManager;
	@Autowired
	LiveFeedBroadcastService broadcastService;

	
	public void checkFeedStatus()
	{
		boolean broadcastUpdate = false;
		List<FeedDTO> feeds = feedStatusDao.getFeeds();
		for(FeedDTO feed : feeds )
		{
			if( feed.getFeedCount() == 1000 )
			{
				feedManager.markFeedComplete( feed.getFeedId() );
				broadcastUpdate = true;
			}
		}
		if( broadcastUpdate )
			broadcastService.broadcastFeedStatus( feedManager.getBroadcastMessage() );
	}
}
