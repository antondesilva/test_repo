package com.livefeed.feed;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.livefeed.util.TimeUtility;

@Component
public class FeedManager {
	
	private Map<Integer, FeedDTO> feedMap;
	private FeedCompletionStatus feedCompletionStatus;
	
	private int completedFeedCount = 0;
	
	public FeedManager()
	{
		feedMap = new HashMap<Integer, FeedDTO>();
		
		FeedDTO feedA = new FeedDTO();
		feedA.setFeedId(1);
		feedA.setFeedName("A");
		feedA.setCompleteForToday(false);
		feedA.setLastFeedEndDate("12/06/17");
		
		FeedDTO feedB = new FeedDTO();
		feedB.setFeedId(2);
		feedB.setFeedName("B");
		feedB.setCompleteForToday(false);
		feedB.setLastFeedEndDate("12/06/17");
		
		FeedDTO feedC = new FeedDTO();
		feedC.setFeedId(3);
		feedC.setFeedName("C");
		feedC.setCompleteForToday(false);
		feedC.setLastFeedEndDate("12/06/17");
		
		FeedDTO feedD = new FeedDTO();
		feedD.setFeedId(4);
		feedD.setFeedName("D");
		feedD.setCompleteForToday(false);
		feedD.setLastFeedEndDate("12/06/17");
		
		FeedDTO feedE = new FeedDTO();
		feedE.setFeedId(5);
		feedE.setFeedName("E");
		feedE.setCompleteForToday(false);
		feedE.setLastFeedEndDate("12/06/17");
		
		this.addFeed(feedA);
		this.addFeed(feedB);
		this.addFeed(feedC);
		this.addFeed(feedD);
		this.addFeed(feedE);
		
		this.feedCompletionStatus = FeedCompletionStatus.INCOMPLETE;
	}
	
	public void addFeed(FeedDTO feed)
	{
		this.feedMap.put( feed.getFeedId(), feed );
	}

	public Map<Integer, FeedDTO> getFeedMap() {
		return feedMap;
	}

	public void setFeedMap(Map<Integer, FeedDTO> feedMap) {
		this.feedMap = feedMap;
	}

	public FeedCompletionStatus getFeedCompletionStatus() 
	{
		return feedCompletionStatus;
	}

	public void setFeedCompletionStatus(FeedCompletionStatus feedCompletionStatus) {
		this.feedCompletionStatus = feedCompletionStatus;
	}
	
	public void updateFeed( int feedId, FeedDTO updatedFeed )
	{
		this.getFeedMap().put( feedId , updatedFeed );
		if( areAllFeedsComplete() )
			this.feedCompletionStatus = FeedCompletionStatus.COMPLETE;
	}
	private boolean areAllFeedsComplete()
	{
		boolean isComplete = true;
		Iterator<Integer> keyItr = this.getFeedMap().keySet().iterator();
		FeedDTO current;
		while( keyItr.hasNext() )
		{
			current = this.getFeedMap().get( keyItr.next() );
			if( !current.isCompleteForToday() )
			{
				return false;
			}
		}
		return isComplete;
	}
	public void markFeedComplete( int feedId )
	{
		FeedDTO feed = this.getFeedMap().get( feedId );
		feed.setCompleteForToday( true );
		feed.setLastFeedEndDate(TimeUtility.currentDate());
		
		if( ++completedFeedCount == this.getFeedMap().size() )
			this.feedCompletionStatus = FeedCompletionStatus.COMPLETE;
		
	}

	public String getBroadcastMessage() {
		List<FeedDTO> feeds = new ArrayList<FeedDTO>();
		Iterator<Integer> keyItr = this.getFeedMap().keySet().iterator();
		FeedDTO current;
		while( keyItr.hasNext() )
		{
			current = this.getFeedMap().get( keyItr.next() );
			feeds.add( current );
		}

		return "new BroadcastDTO().setFeeds( feeds );";
	}
	
}
