package com.livefeed.feed;

import java.util.List;

public class BroadcastDTO {
	
	List<FeedDTO> feeds;

	public List<FeedDTO> getFeeds() {
		return feeds;
	}

	public void setFeeds(List<FeedDTO> feeds) {
		this.feeds = feeds;
	}
	
	
}
