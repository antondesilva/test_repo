package com.livefeed.feed;

import java.util.List;

public interface FeedStatusDAO {
	public List<FeedDTO> getFeeds();
}
