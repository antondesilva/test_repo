package com.livefeed.feed;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class FeedStatusDAOImpl implements FeedStatusDAO {
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public List<FeedDTO> getFeeds() {
		List<FeedDTO> feeds = jdbcTemplate.queryForList("SELECT * FROM LFDBO.FEED_STATUS", FeedDTO.class);
		return feeds;
	}

}
