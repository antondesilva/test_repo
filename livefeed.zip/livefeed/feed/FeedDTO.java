package com.livefeed.feed;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class FeedDTO implements RowMapper<FeedDTO> {
	
	private int feedId;
	private int feedCount;
	private String feedName;
	private String lastFeedEndDate;
	private boolean isCompleteForToday = false;
	
	public String getFeedName() {
		return feedName;
	}
	public void setFeedName(String feedName) {
		this.feedName = feedName;
	}
	public String getLastFeedEndDate() {
		return lastFeedEndDate;
	}
	public void setLastFeedEndDate(String lastFeedEndDate) {
		this.lastFeedEndDate = lastFeedEndDate;
	}
	public boolean isCompleteForToday() {
		return isCompleteForToday;
	}
	public void setCompleteForToday(boolean isCompleteForToday) {
		this.isCompleteForToday = isCompleteForToday;
	}
	public int getFeedId() {
		return feedId;
	}
	public void setFeedId(int feedId) {
		this.feedId = feedId;
	}
	
	@Override
	public FeedDTO mapRow(ResultSet resultSet, int arg1) throws SQLException {
		FeedDTO feed = new FeedDTO();
		feed.setFeedId( resultSet.getInt("feed_id"));
		feed.setFeedCount( resultSet.getInt("feed_count"));
		return feed;
	}
	public int getFeedCount() {
		return feedCount;
	}
	public void setFeedCount(int feedCount) {
		this.feedCount = feedCount;
	}
	
	
	
	
}
