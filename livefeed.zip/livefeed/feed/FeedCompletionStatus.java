package com.livefeed.feed;

public enum FeedCompletionStatus {
	COMPLETE,
	INCOMPLETE
}
